
# . -----------------------------------------------------------------------

rm(list = ls())

source('.project.settings.R')

dt. <- readRDS('DATA derived/dt.all.visits.rds')

# params. <- c('SARA','FARS.E','fSARA','SARA.ax','SARA.ki','fane7','ADL')
# labs.   <- c('SARA','USS','fSARA','SARA.ax','SARA.ki', 'E7','ADL')
params. <- c('SARA','FARS.E','fSARA', .l.FARS.E, .l.sara, .l.fsara[c(1,2,4)])
labs.   <- c('SARA','FARS.E','fSARA', .l.FARS.E, .l.sara, .l.fsara[c(1,2,4)])
# labs.   <- c('SARA','USS','fSARA',  'E7','ADL')

dt. %<>% 
  mutate( paramcd = factor(paramcd, 
                           labels = labs.,
                           levels = params.,
  )) %>% 
  filter( !is.na(paramcd ) )


dt. %<>% 
  filter(has.both) %>% 
  group_by(study, sjid, paramcd) %>% 
  filter(avisitn==min(avisitn))

dt.$paramcd %>% table

dt. %<>% 
  .gs() %>% filter(avisitn == min(avisitn)) %>% 
  spread(paramcd, aval)

dt.

library(tidyverse)
library(psych)

# Define function to compute alpha by study and scale
compute_alpha_by_study <- function(data, item_list, scale_name) {
  data %>%
    group_by(study) %>%
    group_map(~{
      alpha_result <- psych::alpha(.x[, item_list], check.keys = TRUE)
      tibble(
        study = .y$study,
        scale = scale_name,
        alpha = alpha_result$total$raw_alpha,
        n = nrow(.x)
      )
    }) %>% bind_rows()
}

# Run for each scale
alpha_sara   <- compute_alpha_by_study(dt., .l.sara,   "SARA")
alpha_fsara  <- compute_alpha_by_study(dt., .l.fsara,  "fSARA")
alpha_fars_e <- compute_alpha_by_study(dt., .l.FARS.E, "FARS-E")

# Combine all results
alpha_results <- bind_rows(alpha_sara, alpha_fsara, alpha_fars_e)

# View
alpha_results


dt.tmp <- filter(dt., fane7<5 )
# Run for each scale
alpha_sara   <- compute_alpha_by_study(dt.tmp, .l.sara,   "SARA")
alpha_fsara  <- compute_alpha_by_study(dt.tmp, .l.fsara,  "fSARA")
alpha_fars_e <- compute_alpha_by_study(dt.tmp, .l.FARS.E, "FARS-E")

# Combine all results
alpha_results2 <- bind_rows(alpha_sara, alpha_fsara, alpha_fars_e)

# View
# 📉 Alpha drops when between-subject variance shrinks.
alpha_results %>% bind_rows(alpha_results2 %>% mutate(set = 'ambulatory only'))



library(eRm)

# Run Rasch Rating Scale Model for each scale
rasch_sara   <- RSM(dt.[, .l.sara])
rasch_fsara  <- RSM(dt.[, .l.fsara])
rasch_farse  <- RSM(dt.[, .l.FARS.E])

# Summary outputs
summary(rasch_sara)
summary(rasch_fsara)
summary(rasch_farse)

# Optional: plot Wright map (person–item map)
plotPImap(rasch_sara)
plotPImap(rasch_fsara)
plotPImap(rasch_farse)

# ✅ Solution: Use the Partial Credit Model (PCM) instead
# The Partial Credit Model is the more flexible Rasch-family model that:
#   
#   Allows different numbers of categories per item,
# 
# Models each item’s thresholds independently,
# 
# Is ideal when your items are ordinal but structurally heterogeneous.
# 
# Use PCM() from eRm:
  
# Drop missing values first
library(eRm)

pcm_sara   <- PCM(dt.[, .l.sara] %>% drop_na())
pcm_fsara  <- PCM(dt.[, .l.fsara] %>% drop_na())
pcm_farse  <- PCM(dt.[, .l.FARS.E] %>% drop_na())

# View results
summary(pcm_sara)
summary(pcm_fsara)
summary(pcm_farse)

# Wright Maps
plotPImap(pcm_sara, main = "SARA Person-Item Map")
plotPImap(pcm_fsara, main = "fSARA Person-Item Map")
plotPImap(pcm_farse, main = "USS / FARS-E Person-Item Map")

  

# several rash modesl for SCA/FA ------------------------------------------
# Subset data for each study
data_fsara_crcsca <- dt. %>% filter(study == "CRCSCA") %>% ungroup %>% select(all_of(.l.fsara)) %>% drop_na() 
data_fsara_unifai <- dt. %>% filter(study == "UNIFAI") %>% ungroup %>% select(all_of(.l.fsara)) %>% drop_na() 

# Fit PCM models
pcm_crcsca <- PCM(data_fsara_crcsca)
pcm_unifai <- PCM(data_fsara_unifai)

# Summaries
summary(pcm_crcsca)
summary(pcm_unifai)

# Person–item maps
plotPImap(pcm_crcsca, main = "fSARA - CRCSCA")
plotPImap(pcm_unifai, main = "fSARA - UNIFAI")

# Item characteristic curves
plotICC(pcm_crcsca, item.subset = 1)
plotICC(pcm_unifai, item.subset = 1)


# Need person covariate vector (study)
study_factor <- dt. %>% drop_na(all_of(.l.fsara))  %>% ungroup%>% pull(study) %>% factor()

# Fit PCM with DIF
pcm_all <- PCM(dt. %>% drop_na(all_of(.l.fsara))  %>% ungroup%>% select(all_of(.l.fsara)))

# Likelihood Ratio test for DIF by study
LRtest(pcm_all, splitcr = study_factor)



# . -----------------------------------------------------------------------


library(eRm)
library(tidyverse)

# Define item list for FARS-E (USS)
# Already defined: .l.FARS.E

# Subset and clean data
data_farse_crcsca <- dt. %>% ungroup %>% 
  filter(study == "CRCSCA") %>%
  select(all_of(.l.FARS.E)) %>%
  drop_na()

data_farse_unifai <- dt. %>%ungroup %>% 
  filter(study == "UNIFAI") %>%
  select(all_of(.l.FARS.E)) %>%
  drop_na()

# Fit PCM models
pcm_farse_crcsca <- PCM(data_farse_crcsca)
pcm_farse_unifai <- PCM(data_farse_unifai)

# Summaries
summary(pcm_farse_crcsca)
summary(pcm_farse_unifai)

# Optional: print item difficulty ranges
cat("Item difficulty range (CRCSCA):\n")
print(range(pcm_farse_crcsca$etapar))

cat("Item difficulty range (UNIFAI):\n")
print(range(pcm_farse_unifai$etapar))

# Person–item maps
plotPImap(pcm_farse_crcsca, main = "FARS-E Person-Item Map: CRCSCA")
plotPImap(pcm_farse_unifai, main = "FARS-E Person-Item Map: UNIFAI")

# Optional: category curves for a specific item (e.g., item 1 = fane1)
plotICC(pcm_farse_crcsca, item.subset = 2, main = "CRCSCA - fane1 Category Curves")
plotICC(pcm_farse_unifai, item.subset = 1, main = "UNIFAI - fane1 Category Curves")






