

# Define coefficients for each SCA type
params <- list(
  SCA1 = list(a0 = 5.4952, ae = -0.0487, ane = 0.0133, gG = 0.1748),
  SCA2 = list(a0 = 7.6301, ae = -0.1051, ane = 0,       gG = 0.2520),
  SCA3 = list(a0 = 7.4908, ae = -0.0564, ane = 0,       gG = 0.2167),
  SCA6 = list(a0 = 6.3470, ae = -0.0901, ane = -0.0285, gG = 0.1738)
)

# Apply prediction formula to demo.sca
demo.sca <- .dd("demo.sca") %>%
  filter( sca %in% c('SCA1','SCA2','SCA3','SCA6')) %>% 
  mutate(
    aoo.pred = purrr::pmap_dbl(
      list(sca, rpt, nor),
      function(sca_type, rpt_exp, rpt_nor) {
        p <- params[[sca_type]]
        if (is.null(p) || is.na(rpt_exp)) return(NA_real_)
        mG <- p$a0 + p$ae * rpt_exp + p$ane * coalesce(rpt_nor, 0)
        aoo <- exp(mG + (p$gG^2 / 2))
        round(aoo, 1)
      }
    )
  )

demo.sca %>% 
  filter(aoo.pred<100) %>% 
  ggplot()+geom_point()+
  aes(x = aoo)+
  aes(y = aoo.pred)+
  facet_wrap(study~sca, ncol = 4)+
  geom_smooth(method = lm)+
  ggpmisc::stat_correlation(
    # label.x = 0.04, 
    # label.y = 0.19
    aes(label = paste(after_stat(rr.label))),
    size =  10 / .pt,
    family = theme_get()$text$family
  )

.sp(l = '1s', ti = 'Predicted AOO by AOO', i = 2)



