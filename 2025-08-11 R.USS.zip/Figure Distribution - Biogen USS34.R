

# . -----------------------------------------------------------------------

rm(list = ls())

source('.project.settings.R')

dt. <- readRDS('DATA derived/dt.all.visits.rds')

# params. <- c('SARA','FARS.E','fSARA','SARA.ax','SARA.ki','fane7','ADL')
# labs.   <- c('SARA','USS','fSARA','SARA.ax','SARA.ki', 'E7','ADL')
params. <- c('SARA','FARS.E','fSARA','fane7','ADL')
labs.   <- c('SARA','USS','fSARA',  'E7','ADL')

dt. %<>% 
  mutate( paramcd = factor(paramcd, 
                           labels = labs.,
                           levels = params.,
  )) %>% 
  filter( !is.na(paramcd ) )

# . -----------------------------------------------------------------------

dt. %<>%
  # filter( has.both ) %>% 
  .gs %>% filter(avisitn == min(avisitn)) %>% .ug %>% 
  # left_join(
  #   .dd('demo.sca') %>%
  #     select( study, sjid, site, sca )
  # ) %>%
  # select( study, sjid, site, sca, avisitn, avisitx, paramcd, aval) %>%
  spread( paramcd, aval ) %>% 
  gather( paramcd, aval, SARA, USS, fSARA, ADL )

dt. %>%
  filter( paramcd == 'USS' ) %>% 
  select( study, avisitx ) %>% .tab

  
dt.tmp <- dt. 

dt.tmp %>% 
  .ug %>% 
  select(study, paramcd) %>% .tab

# SARA, fSARA //SARA.ax/app vs USS ---------------------------------------------

dt.tmp %<>%
  left_join(
    .dd('steps') %>%
      select( study, sjid, avisitn, fds, starts_with('balance.step'), starts_with('fprint') )
  ) %>% 
  mutate( amb.fds = ifelse( fds < 5, 'amb', 'non-amb.' )) %>% 
  mutate( amb.E7  = ifelse( E7  < 5, 'amb', 'non-amb.' ))

fprint.reg <- c('000|000|0','100|000|0','110|000|0','111|000|0','111|100|0','111|110|0','111|111|0','111|111|1')

dt.tmp %>% 
  select( ends_with('.4') ) %>% 
  mutate( regular = if_else( fprint.4 %in% fprint.reg, T,F ) ) %>% 
  filter( regular ) %>% 
  table

# graph for biogen --------------------------------------------------------

dt.tmp %>%
  
  # filter( has.both ) %>%
  filter( paramcd == 'USS' ) %>% 
  filter( study   == 'UNIFAI' ) %>% 
  filter( !is.na(amb.E7)) %>% 
  
  left_join(
    .ds.UNIFAI('vf') %>% select(study, sjid, avisitn, adt )
  ) %>% 
  left_join(
    .dd('demo') %>% select(study, sjid, dob)
    ) %>% 
  mutate( age = as.numeric( adt - dob ) / 365.25 ) %>% 
  filter( age < 18 ) %>% 

  # mutate( balance.step = cut(balance.step.0, c(-1,5,6,8)))  %>% select(balance.step) %>% table
  mutate( balance.step = cut(balance.step.0, c(-1,5,6,8), labels = c('can stand and walk','can walk, but not stand (<15s)','neither'))) %>% 
  
  ggplot()+geom_histogram(bins = 36)+
  aes(x = aval)+
  aes(fill = factor(balance.step))+
  facet_wrap(amb.E7~study, ncol = 1)+
  ggsci::scale_fill_d3()+
  geom_vline(xintercept = c(30,34))+
  labs(color = 'Ambulation (E7)')


dt.tmp %>%
  filter( has.USS ) %>%
  # sample_frac(.9) %>% 
  
  mutate( paramcd = factor(paramcd, c('SARA','fSARA','USS'))) %>%
  filter( !is.na(paramcd)) %>% 
  
  mutate( facet_label = paste ( paramcd, study )) %>% 
  

  
  ggplot() +
  geom_histogram(bins = 30) +
  # aes(x = aval, fill = amb.E7)+
  aes(x = aval, fill = factor(balance.step))+
  facet_wrap( ~ facet_label, scales = "free", ncol = 2) +
  ggsci::scale_fill_d3() +
  ggsci::scale_fill_d3() +
  .theme(base_size = 14)
# .sp( )# has.USS.sp( )


dt.tmp %>%
  
  filter( has.both ) %>%
  # filter(!is.na(E7)) %>% 
  mutate( paramcd = factor(paramcd, c('SARA','fSARA','USS'))) %>%
  filter( !is.na(paramcd)) %>% 
  # filter(!sca %in% c('SCA1','SCA10','SCA8','SCA7','RFC1')) %>%
  
  mutate(facet_label = paste ( paramcd, study )) %>% 
  
  ggplot() +
  geom_density(aes(y = after_stat(count)), alpha = 0.75) +
  # geom_histogram(bins = 30) +
  # aes(x = aval, fill = amb.E7)+
  aes(x = aval, fill = step.act)+
  facet_wrap( ~ facet_label, scales = "free", ncol = 2) +
  ggsci::scale_fill_d3() +
  ggsci::scale_fill_d3() +
  .theme(base_size = 14)+
  labs(fill = 'Ambulation (E7)')



