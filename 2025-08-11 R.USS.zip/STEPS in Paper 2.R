
# . -----------------------------------------------------------------------

rm(list = ls())

source('.project.settings.R')

dt. <- readRDS('DATA derived/uss.etc.rds')

vds. <- bind_rows(
  .dd('visit.dates.CRCSCA') %>% 
    select(study, sjid, avisitn, adt),
  .ds.UNIFAI('vf') %>% 
    select(study, sjid, avisitn, adt)
  )

dt. <- .dd('steps') %>% 
  filter(study %in% c('CRCSCA', 'UNIFAI')) %>% 
  left_join(vds.) %>%
  filter( adt >= as.Date ("2024-03-01") | study == 'UNIFAI' ) 

dt. %>% 
  .ug %>% 
  select( study, step ) %>% .tab

# stance.labs. <- c(
#   'sitting\nposition','feet\napart','feet\napart\n(eyes closed)','feet\ntogether','feet\ntogether\n(eyes closed)',
#   'in tandem', 'on one foot', 'tandem walk', 'gait'
# )
# 
# params. <- .l.FARS.E


stance.labs. <- c(
  'feet\napart','feet\napart\n(eyes closed)','feet\ntogether','feet\ntogether\n(eyes closed)',
  'in tandem', 'on one foot'
)

params. <- .l.FARS.E[c(2:7)]

dt. %<>% 
  mutate( paramcd = factor(paramcd, 
          labels = stance.labs.,
          levels = params.,
          )) %>% 
  filter( !is.na(paramcd ) ) %>% 
  left_join(.dd('steps') %>% select(study, sjid, avisitn, amb))

# selection ---------------------------------------------------------------

dt.tmp <- dt. %>% 
  # filter   (amb == 'ambulatory') %>%
  # filter   (study != 'FACOMS') %>%
  group_by(sjid) %>% filter(adt == min(adt)) %>%
  .ug

# graph ----------------------------------------------------------------

dt.tmp %>% 
  .gs %>% 
  filter(avisitn == min(avisitn)) %>%
  mutate(aval = round(aval)) %>% 
  ggplot()+geom_bar(color = 'black')+
  aes(x = paramcd)+
  aes(fill = factor(aval))+
  scale_fill_brewer(palette = 'Greens')+
  facet_wrap( ~study, scales = 'free_y', ncol = 2)+
  scale_x_discrete(labels = stance.labs.)+
  labs(
    fill = "Result (4 = Unable)",
    x    = 'USS Item',
    x    = 'Stance Position'
    )+
  theme(legend.position = 'right')

# .sp(l = '1s', i = 2)

