

dt. <- .dd('visit.dates.CRCSCA') %>% 
  left_join(.dd('demo.sca') %>% 
              select(-age_bl)) %>% 
  filter(!is.na(sca))

dt. %>% 
  # filter(sca == 'SCA8') %>% 
  filter(sca == 'SCA27B') %>% 
  .gs %>% 
  # arrange(adt)
  group_by(site) %>% 
  ggplot()+geom_histogram()+
  facet_wrap(~site)+
  aes(x = adt)+
  aes(fill = sca)+
  .theme()

dt. %>% 
  ggplot()+geom_histogram()+
  facet_wrap(~sca)+
  aes(x = adt)+
  aes(fill = sca4)+
  .theme()

.sp(l = '1s', i = 2)  
.sp()
