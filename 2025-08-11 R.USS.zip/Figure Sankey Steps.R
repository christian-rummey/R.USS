

dt.tmp <- bind_rows(
  .dd('sara'),
  .dd('fars')
) %>%
  filter( paramcd %in% c('s1.gait', "fane1", "fane2a", "fane2b", "fane3a", "fane3b", "fane4", "fane5", 
                         "fane6", "fane7") ) %>% 
  filter( !is.na(aval) ) %>% 
  select(-avisit, -age, -time.) %>% 
  
  # mutate( aval = round(aval)) %>% 
  mutate( aval = ifelse(aval<4, 0, 4)) %>% 
  
  spread( paramcd, aval ) %>% 
  filter( !is.na( fane7 ) & !is.na(s1.gait)  )

dt.tmp %<>% filter(fane7<5)

dt.tmp %<>% filter(fane7<5)

library(ggalluvial)

dt.flow <- dt.tmp %>%
  group_by(sjid) %>% 
  filter(adt == min(adt)) %>% 
  distinct(study, sjid, avisitn, fane2a, fane2b, fane3a, fane3b, fane4, fane5 ) %>%  # ensure unique subjects
  select(study, sjid, avisitn, fane2a, fane2b, fane3a, fane3b, fane4, fane5 ) %>%  # ensure unique subjects
  left_join(
    .dd('steps') %>% 
      select(study, sjid, avisitn, balance.step.0)
  ) %>% 
  group_by(study, balance.step.0) %>% 
  count(fane2a, fane2b, fane3a, fane3b, fane4, fane5, name = "n")   # count transitions


dt.flow %>% 
  ggplot() +
  aes(
    axis1 = fane2a, axis2 = fane3a,
    axis3 = fane2b, axis4 = fane3b,
    axis5 = fane4 , axis6 = fane5, 
    y = n) +
  geom_alluvium(aes(fill = factor(balance.step.0)), width = 1/12) +
  geom_stratum(width = 1/12, fill = "grey90", color = "black") +
  geom_text(stat = "stratum", aes(label = after_stat(stratum))) +
  scale_x_discrete(limits = c("E2A", "E3A", "E2B", "E3B", "E4", 'E5'), expand = c(.05, .05)) +
  # labs(title = "Transition from E7 to Gait Score", y = "Number of Subjects") +
  theme_minimal()+
  facet_wrap(~study, scales = 'free_y')


