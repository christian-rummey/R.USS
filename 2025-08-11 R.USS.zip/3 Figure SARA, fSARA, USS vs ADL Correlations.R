
# . -----------------------------------------------------------------------

rm(list = ls())

source('.project.settings.R')

dt. <- readRDS('DATA derived/dt.all.visits.rds')

# params. <- c('SARA','FARS.E','fSARA','SARA.ax','SARA.ki','fane7','ADL')
# labs.   <- c('SARA','USS','fSARA','SARA.ax','SARA.ki', 'E7','ADL')
params. <- c('SARA','FARS.E','fSARA','fane7','ADL')
labs.   <- c('SARA','USS','fSARA',  'E7','ADL')

dt. %<>% 
  mutate( paramcd = factor(paramcd, 
                           labels = labs.,
                           levels = params.,
  )) %>% 
  filter( !is.na(paramcd ) )

# %>% 
#   left_join(.dd('steps') %>% select(study, sjid, avisitn, amb))

# no flooring in corelations! ---------------------------------------------

# dt. %<>%
#   mutate(aval = floor(aval)) %>%
#   .gs %>% 
#   # filter(avisitx != 0 & (avisitn == min(avisitn)))
#   # filter(avisitn == min(avisitn)) %>%
#   .ug

# . -----------------------------------------------------------------------

dt. %>%
  select( study, sjid, avisitx, paramcd, aval) %>% 
  spread( paramcd, aval ) %>% 
  filter( !is.na(USS) ) %>% 
  unique() %>% 
  .ug %>% 
  select( study, avisitx ) %>% .tab
   

dt. %<>% 
  # left_join(
  #   
  #   .dd('demo.sca') %>% 
  #     select( study, sjid, site, sca )
  # ) %>% 
  # select( study, sjid, site, sca, avisitn, avisitx, paramcd, aval) %>% 
  .gsv %>% 
  # filter(n()==5) %>% 
  spread( paramcd, aval ) 

dt. %<>% 
  mutate( amb = ifelse(E7<5, 'amb', 'non-amb.')) %>% 
  filter( !is.na(SARA) & !is.na(USS) | study == 'UNIFAI')

dt.tmp <- dt. %>% 
  gather( paramcd, aval, SARA, fSARA, USS )

dt.tmp %>% 
  .ug %>% 
  select(study, paramcd) %>% .tab

# SARA, fSARA //SARA.ax/app vs USS ---------------------------------------------

dt.tmp %>% 
  .ug %>% 
  filter(ADL==0) %>% filter(paramcd == 'USS') %>%
  arrange(-aval) %>% 
  filter( study %in% c('CRCSCA')) %>% 
  select(sjid) %>% 
  left_join(
    .dd('adl') %>% 
      filter( paramcd %in% c( .l.adl, 'ADL' )) %>% 
      spread( paramcd, aval )
  ) %>% .p
  # filter(aval>25) %>% 
  # filter(ADL == 6 )

dt.tmp %>%
  filter(has.both) %>% 
  .gs %>% filter(avisitn == min(avisitn)) %>% ungroup %>% 
  filter(!is.na(aval)) %>% 
  filter(!is.na(E7)) %>% 
  # .gs %>% filter(avisitn == min(avisitn)) %>%
  # filter( paramcd %in% c('SARA','fSARA','SARA.ax','SARA.ki')) %>%
  filter( paramcd %in% c('SARA','fSARA','USS')) %>%
  mutate( paramcd = factor(paramcd, c('SARA','fSARA','USS'))) %>%
  # filter(!sca %in% c('SCA1','SCA10','SCA8','SCA7','RFC1')) %>%
  ggplot()+geom_point()+
  aes ( y = ADL, x = aval )+
  # aes ( shape = amb )+.ssmA+
  aes ( color = amb )+ggsci::scale_color_d3()+
  # aes ( color = amb )+
  # aes ( color = amb )+
  facet_wrap( paramcd~study, scales = 'free_y', ncol = 2 )+
  ggpmisc::stat_correlation(
    # label.x = 0.04, 
    # label.y = 0.19
    aes(label = paste(after_stat(rr.label))),
        size =  10 / .pt,
        family = theme_get()$text$family
    )+
  # stat_regline_equation    (  )+
  # stat_regline_equation    ( label.x = 2 , label.y = 39 )+
  geom_smooth(method = lm, se =F)+
  # coord_cartesian(ylim = c(0, 36))+
  coord_flip(xlim = c(0, 36))+
  labs(color = 'Ambulation (by E7)')+
  .theme(base_size = 14)
# .sp( ti = 'USS vs SARA.ax, SARA.app' )
# .sp( ti = 'fSARA.ax, SARA' )

# USS by duration vs SARA -------------------------------------------------

dt.tmp <- dt. %>% 
  filter(!is.na(USS)) %>% 
  filter(!is.na(SARA)) %>% 
  filter(!is.na(amb)) %>% 
  filter(!is.na(dur)) %>% 
  gather( paramcd, aval, USS, SARA, fSARA, SARA.ax, SARA.ki ) 

dt.tmp %>% 
  .ug %>% 
  select(study, paramcd) %>% .tab

# sjids <- dt.tmp %>% 
#   .gs %>% 
#   filter(paramcd == 'USS') %>% 
#   filter( min(time.)>0 ) %>% select(sjid)
# 
# dt.tmp %>% 
#   inner_join(sjids) %>% 
#   spread(paramcd, aval)

dt.tmp %>% 
  filter(amb == 'amb') %>% 
  # filter(study == 'CRCSCA') %>% 
  # filter(paramcd == 'USS') %>% 
  .gs() %>% 
  filter(!is.na(aval)) %>% 
  filter(dur < 30) %>%
  # filter( paramcd %in% c('SARA','fSARA')) %>%
  # filter( !paramcd %in% c('SARA','fSARA')) %>% 
  # filter(!sca %in% c('SCA1','SCA10','SCA8','SCA7','RFC1')) %>%
  ggplot()+geom_point()+
  geom_line(aes(group= sjid))+
  aes ( x = dur, y = aval )+
  aes ( color = amb )+ggsci::scale_color_d3()+
  # aes ( color = amb )+
  # aes ( color = amb )+
  facet_grid( study~paramcd, scales = 'free_y' )+
  ggpmisc::stat_correlation(
    # label.x = 0.04,
    # label.y = 0.19
    aes(label = paste(after_stat(rr.label))),
    size =  10 / .pt,
    family = theme_get()$text$family,
    # color = 'red'
  )+
  # stat_regline_equation    (  )+
  # stat_regline_equation    ( label.x = 2 , label.y = 39 )+
  geom_smooth(method = lm, se =F, color = 'red')+
  # coord_cartesian(ylim = c(0, 36))+
  labs(shape = 'Ambulation (by E7)')+
  .theme(base_size = 14)

# .sp( ti = 'Correlation by Duration.age', l = '1s', i = 2 )

dt.tmp %>% spread(paramcd, aval) %>% filter(USS== 0) %>% .p

# SARA, fSARA, SARA.ax vs USS ---------------------------------------------

