
# all everything ----------------------------------------------------------

source('.project.settings.R')

# need to derive Louise SARA data

dt. <- bind_rows(
  .dd('fars') %>% filter(study %in% c('CRCSCA','UNIFAI','TRACKFA'), paramcd %in% c(.l.FARS.E, 'FARS.E')) %>% .add.time(),
  .dd('sara') %>% filter(study %in% c('CRCSCA','UNIFAI','TRACKFA'), paramcd %in% c('SARA.ap', 'SARA.gp', 'SARA.ax', 'fSARA','SARA'))
  ) %>% 
  left_join( 
    .dd('steps') %>% 
      select( study, sjid, avisitn, fds.act )
    )

# to long -----------------------------------------------------------------

dt. %<>% 
  select( study, sjid, avisitn, paramcd, aval, fds.act ) %>% 
  filter( paramcd %in% c('FARS.E',.l.sara.ax,'fSARA','SARA','SARA.ax','SARA.ap','SARA.gp','fds') ) %>% 
  spread ( paramcd, aval) %>% 
  filter ( !is.na( FARS.E ) ) %>% 
  filter ( !is.na( SARA   ) ) %>% 
  rename ( USS = FARS.E ) %>% 
  left_join( .dd('demo.sca') %>% select( study, sca, sjid, aoo  )) %>% 
  mutate( sca = ifelse( study %in% c('FACOMS','TRACKFA'), 'FA', sca ) ) %>% 
  filter( !is.na( sca )) %>%
  # mutate( dur = age-aoo) %>% 
  gather ( paramcd, aval, USS, 'fSARA','SARA','SARA.ax','SARA.ap','SARA.gp')

dt. %<>%
  # filter(study == 'CRCSCA') %>%
  left_join(
    .dd('visit.dates.CRCSCA') %>% 
      select(sjid, avisitn, age) %>% 
      unique
    )


# .dd('fars') %>% filter(study == 'CRCSCA') %>%
#   filter(!is.na(aval)) %>%
#   spread(paramcd, aval) %>%
#   print(n=53)
#   # .ct

# USS graphs for F2F ------------------------------------------------------

# AA <- dt %>%
#   ggplot()+geom_histogram()+
#   aes(x  = USS)+
#   # aes(fill = sca4)+
#   xlab('Upright Stability')
# 
# A <- dt %>%
#   ggplot()+geom_point()+
#   aes(x = age, y = USS)+
#   ggpmisc::stat_correlation(aes(label = paste(..rr.label..)))+
#   geom_smooth( method = lm )+
#   coord_cartesian(ylim = c(0,36))+
#   xlab('Age')+
#   ylab('Upright Stability')
# 
# B <- dt %>%
#   mutate(dur = age - aoo ) %>% 
#   ggplot()+geom_point()+
#   aes(x = dur, y = USS)+
#   ggpmisc::stat_correlation(aes(label = paste(..rr.label..)))+
#   geom_smooth( method = lm )+
#   coord_cartesian(ylim = c(0,36))+
#   xlab('Disease Duration')+
#   ylab('Upright Stability')
# 
# C <- dt %>%
#   ggplot()+geom_point()+
#   aes(x = SARA, y = USS)+
#   ggpmisc::stat_correlation(aes(label = paste(..rr.label..)))+
#   geom_smooth( method = lm )+
#   coord_cartesian(ylim = c(0,36))+
#   xlab('SARA Score')+
#   ylab('Upright Stability')
# 
# ggarrange(AA, A, B, C)  


# barcharts ---------------------------------------------------------------


dt. <- bind_rows(
  .dd('fars') %>% filter(study %in% c('CRCSCA','FACOMS'), paramcd %in% c(.l.FARS.E, 'FARS.E')) %>% .add.time(),
  .dd('sara') %>% filter(study %in% c('CRCSCA','FACOMS')),
  .dd('steps') %>% select( study, sjid, avisitn, fds.act ) %>% 
    mutate ( paramcd = 'fds', aval = fds.act) %>% 
    select ( -fds.act) %>% 
    filter ( !is.na(aval))
)

dt. %>% 
  spread(paramcd, aval) %>% 
  filter(FARS.E < 32) %>% 
  gather(paramcd, aval, c(.l.FARS.E, 'FARS.E','SARA')) %>% 
  filter(paramcd %in% c(.l.FARS.E)[2:7]) %>% 
  mutate_at('aval', round,0) %>% 
  group_by(study, paramcd) %>%
  ggplot()+geom_bar()+
  aes(x = paramcd)+aes(fill = factor(aval))+
  facet_wrap(~study, scales = 'free_y')+
  scale_fill_brewer(palette = 'Greens')+
  .theme(base_size=20)+
  theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1))+
  .leg('none')


dt. %>% 
write_rds('DATA derived/uss.etc.rds')




