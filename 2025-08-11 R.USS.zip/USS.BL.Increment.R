
# data: E7, FARS.E, mFARS ------------------------------------------------

dt. <- .dd('fars') %>%
  # select( -hpf, -fpf ) %>% 
  filter( study == 'UNIFAI') %>% 
  filter( paramcd %in% c('fane7','mFARS','FARS.E')) %>% 
  # filter(study %in% c('FACOMS','FACHILD')) %>% 
  spread(paramcd, aval) %>% 
  .add.time() %>% 
  group_by(study, sjid) %>% 
  mutate(time. = age-min(age))

bl <- dt. %>% 
  filter(time. == 0) %>% 
  select(study, sjid, bl.age = age, bl.e7 = fane7, bl.mFARS = mFARS, bl.USS = FARS.E)%>% 
  group_by(sjid) %>% slice(1)


# fitler non-ambulatory at BL ---------------------------------------------

dt. %<>% 
  left_join(bl) %>% 
  left_join(.dd('demo') %>% select(study, sjid, aoo)) %>% 
  filter(bl.e7<5) 

# adult patients with pediatric onset -------------------------------------
# n = 1079
# 792, aoo < 18
# bl.age > 18, 513
# 241, aoo < 18, bl.age > 18
# 241 / 513

dt. %>% 
  group_by(sjid) %>%
  filter( avisitn == min(avisitn) ) %>% 
  filter( bl.age > 18 ) %>% 
  filter( aoo < 18 )


# Baseline Histograms -----------------------------------------------------

bl %>% 
  mutate(amb = if_else(bl.e7<5, 'ambulatory','non-ambulatory')) %>% 
  gather(paramcd, aval, bl.mFARS, bl.USS, bl.age, bl.e7) %>% 
  filter(paramcd != 'bl.age') %>% 
  filter(paramcd != 'bl.e7') %>% 
  filter(amb     == 'ambulatory') %>%
  ggplot()+
  geom_histogram()+
  aes(x = aval)+
  # aes(fill = amb)+
  facet_wrap(~paramcd, scales = 'free_x')+
  # .leg_none+
  .theme()

bl %>% 
  # mutate(bl.USS = round(bl.USS,  0)) %>% 
  mutate(amb = if_else(bl.e7<5, 'ambulatory','non-ambulatory')) %>% 
  gather(paramcd, aval, bl.mFARS, bl.USS, bl.age, bl.e7) %>% 
  filter(paramcd == 'bl.USS') %>% 
  filter(amb     == 'ambulatory') %>%
  # mutate(Subgroup = ifelse( bl.USS > 20 & bl.USS < 30))
  ggplot()+
  geom_histogram(binwidth = 1)+
  aes(x = aval)+
  # aes(fill = amb)+
  facet_wrap(~paramcd, scales = 'free_y')+
  # .leg_none+
  .theme()+
  coord_flip()


# -------------------------------------------------------------------------


  
# 955 patients, 4869 FU visits

# 195 have only one FU visit
# 760 with 4665 with only one FU visit - this seems to make 0 difference
dt. %<>% 
  filter(n()>1)

# dt. %<>% filter(bl.age<18)
# dt. %<>% filter( aoo<15 )


# tte ---------------------------------------------------------------------

dt <- dt. %>% 
  mutate( event = ifelse(fane7>4, 1, 0) ) %>% 
  select( study, sjid, bl.age, bl.USS, bl.mFARS, time., event )

tte.ev <- dt %>% 
  filter( max(event) == 1 ) %>% 
  filter( event == 1 ) %>% 
  filter( time. == min(time.) )

tte.nv <- dt %>% 
  filter( max(event) == 0 ) %>% 
  filter( time. == max(time.) )

tte <- bind_rows(
  tte.ev, 
  tte.nv
)

quantile(tte$bl.mFARS)
quantile(tte$bl.USS)


# . -----------------------------------------------------------------------



tte.x <- tibble()

# parameter for range of mFARS/FARS.E
# we will use a range of 
# -ipct to +ipct pct of the baseline score

ipct <- 5

for( i in seq(1,100,1)) {
  tte.x %<>%
    bind_rows(
      tte %>%
        ungroup %>% 
        mutate(bl.pct = 100*bl.USS/36) %>% 
        filter(bl.pct > i-ipct & bl.pct < i+ipct) %>%
        mutate(
          n=n(),
          mean.score = mean(bl.USS),
          min.score = min(bl.USS),
          max.score = max(bl.USS)
        ) %>% 
        mutate(i  = i) %>%
        mutate(ir = paste(sprintf("%02d", i), sprintf("%02d", i+5), sep = '-'))%>% 
        mutate(scale = 'FARS.E')
    )
}

for( i in seq(1,100,1)) {
  tte.x %<>%
    bind_rows(
      tte %>%
        ungroup %>% 
        mutate(bl.pct = 100*bl.mFARS/93) %>% 
        filter(bl.pct > i-ipct & bl.pct < i+ipct) %>%
        mutate(mean.score = mean(bl.mFARS), n = n()) %>% 
        mutate(i  = i) %>%
        mutate(ir = paste(sprintf("%02d", i), sprintf("%02d", i+5), sep = '-')) %>% 
        mutate(scale = 'mFARS')
    )
}

tte.x %<>% 
  mutate(strata = paste(i, scale))

# survival ----------------------------------------------------------------

# no dups included
tte %>% group_by(sjid) %>% filter(n()>1)

fit <- survfit(Surv(tte.x$time., tte.x$event) ~ strata, data = tte.x) 

smry <- survfit(Surv(tte.x$time., tte.x$event)~strata, data = tte.x) %>% 
  summary()

dt.tmp <- smry$table %>%  as_tibble %>%
  bind_cols(term = rownames(smry$table)) %>% 
  mutate(term = gsub('strata=', '', term)) %>%
  separate(col = 'term', into = c('i', 'scale'), sep = ' ') %>% 
  mutate(i = as.numeric(i)) %>% 
  left_join(tte.x %>% select(i, scale, n, mean.score, min.score, max.score) %>% unique()) %>% 
  rename(X0.95UCL = `0.95UCL`, X0.95LCL = `0.95LCL`) %>% 
  mutate(scale = ifelse(scale == 'FARS.E','FARS E / Upright Stability','Total mFARS'))



dummy <- data.frame(data.frame(scale = c('FARS E / Upright Stability','Total mFARS','FARS E / Upright Stability','Total mFARS'), 
                               mean.score = c(36,80,0,0), median = c(18,16,0,0), X0.95UCL = as.numeric(c(NA, NA)), X0.95LCL = as.numeric(c(NA, NA)))) %>% as_tibble()

dt.tmp %>%
  filter(n>70) %>%
  # filter(!is.na(`0.95LCL`)) %>% 
  ggplot()+geom_pointrange(alpha = 0.30)+
  aes(ymin = X0.95UCL, ymax = X0.95LCL)+
  aes(x = mean.score, y = median)+
  aes(color = scale)+
  theme_minimal(base_size = 20)+
  geom_smooth              ( method = 'lm'              , data = dt.tmp %>% filter(!is.na(X0.95UCL)))+
  stat_regline_equation    ( label.x = 2 , label.y = 5  , data = dt.tmp %>% filter(!is.na(X0.95UCL)))+
  ggpmisc::stat_correlation( label.x = .04, label.y = 0.19, data = dt.tmp %>% filter(!is.na(X0.95UCL)), aes(label = paste(..rr.label..)))+
  facet_grid(.~scale, scales = 'free')+
  xlab('Baseline Score')+
  ylab('Median Time to LoA (95%CI)')+
  # coord_cartesian(xlim = c(0,93), ylim = c(0,18))+
  geom_blank(data=dummy) +
  .leg_none+.box

# .sp(ipct, l = 1)

# n/events ----------------------------------------------------------------



dt.tmp %>%
  ggplot()+geom_point(alpha = 0.30)+
  aes(x = mean.score, y = events/n)+
  # aes(color = scale)+
  aes(color = factor(i))+
  theme_minimal(base_size = 20)+
  geom_smooth              ( method = 'lm'              , data = dt.tmp %>% filter(!is.na(X0.95LCL)))+
  # stat_regline_equation    ( label.x = 2 , label.y = 5  , data = dt.tmp %>% filter(!is.na(X0.95UCL)))+
  ggpmisc::stat_correlation( label.x = .04, label.y = 0.19, data = dt.tmp %>% filter(!is.na(X0.95UCL)), aes(label = paste(..rr.label..)))+
  # xlab('Baseline Score')+
  # ylab('Median Time to LoA (95%CI)')+
  # coord_cartesian(xlim = c(0,36), ylim = c(0,1))+
  # .leg_none+
  facet_wrap(~scale, scales = 'free_x')
# 
