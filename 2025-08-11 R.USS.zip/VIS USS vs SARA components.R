

# #NEED TO REDO Correlations on percentual scale --------------------------

dt. <- bind_rows(
  .dd('fars') %>% filter(study %in% c('CRCSCA','FACOMS'), paramcd == 'FARS.E') %>% .add.time(),
  .dd('sara') %>% filter(study %in% c('CRCSCA','FACOMS'))
  )

dt. %<>% 
  filter( study == 'CRCSCA') %>% 
  select(-age) %>% 
  left_join( .ds.CRCSCA('sara') %>% select( sjid, avisit, age )) %>% 
  select( study, sjid, age, paramcd, aval) %>% 
  filter( paramcd %in% c('FARS.E',.l.sara.ax,'SARA','SARA.ax','SARA.ap','SARA.gp') ) %>% 
  group_by( sjid, age, paramcd ) %>% 
  slice(1) %>% 
  spread ( paramcd, aval) %>% 
  filter ( !is.na( FARS.E ) ) %>% 
  filter ( !is.na( SARA   ) ) %>% 
  rename ( USS = FARS.E ) %>% 
  left_join( .dd('demo.sca') %>% select( study, sjid, aoo  )) %>% 
  mutate( dur = age-aoo) %>% 
  gather ( paramcd, aval, .l.sara.ax,'SARA','SARA.ax','SARA.ap','SARA.gp')

dt. %>% 
  # filter(is.na(study))
  filter(study == 'CRCSCA') %>% 
  ggplot()+geom_point()+
  aes ( y = USS, x = aval )+
  # aes ( shape = study )+.ssmA+
  facet_wrap( ~paramcd, scales = 'free_x' )+
  # geom_smooth(method = lm, aes(shape = NA))+
  geom_abline()+
  .box


dt <- dt. %>% 
  filter(study == 'CRCSCA') %>% 
  spread(paramcd, aval) %>% 
  arrange(USS)


# .dd('fars') %>% filter(study == 'CRCSCA') %>% 
#   filter(!is.na(aval)) %>% 
#   spread(paramcd, aval) %>% 
#   print(n=53)
#   # .ct

# USS graphs for F2F ------------------------------------------------------

AA <- dt %>%
  ggplot()+geom_histogram()+
  aes(x  = USS)+
  # aes(fill = sca4)+
  .theme()+
  xlab('Upright Stability')
  
A <- dt %>%
  ggplot()+geom_point()+
  aes(x = age, y = USS)+
  ggpmisc::stat_correlation(aes(label = paste(..rr.label..)))+
  geom_smooth( method = lm )+
  .theme()+
  coord_cartesian(ylim = c(0,36))+
  xlab('Age')+
  ylab('Upright Stability')
  
B <- dt %>%
  ggplot()+geom_point()+
  aes(x = dur, y = USS)+
  ggpmisc::stat_correlation(aes(label = paste(..rr.label..)))+
  geom_smooth( method = lm )+
  .theme()+
  coord_cartesian(ylim = c(0,36))+
  xlab('Disease Duration')+
  ylab('Upright Stability')
  
C <- dt %>%
  ggplot()+geom_point()+
  aes(x = SARA, y = USS)+
  ggpmisc::stat_correlation(aes(label = paste(..rr.label..)))+
  geom_smooth( method = lm )+
  .theme()+
  coord_cartesian(ylim = c(0,36))+
  xlab('SARA Score')+
  ylab('Upright Stability')
  
ggarrange(AA, A, B, C)  


# barcharts ---------------------------------------------------------------


dt. <- bind_rows(
  .dd('fars') %>% filter(study %in% c('CRCSCA','FACOMS'), paramcd %in% c(.l.FARS.E, 'FARS.E')) %>% .add.time(),
  .dd('sara') %>% filter(study %in% c('CRCSCA','FACOMS'))
)

dt. %>% 
  spread(paramcd, aval) %>% 
  filter(FARS.E < 32) %>% 
  gather(paramcd, aval, c(.l.FARS.E, 'FARS.E','SARA')) %>% 
  filter(paramcd %in% c(.l.FARS.E)[2:7]) %>% 
  mutate_at('aval', round,0) %>% 
  group_by(study, paramcd) %>%
  ggplot()+geom_bar()+
  aes(x = paramcd)+aes(fill = factor(aval))+
  facet_wrap(~study, scales = 'free_y')+
  scale_fill_brewer(palette = 'Greens')+
  .theme()+
  theme(axis.text.x = element_text(angle = 45, vjust = 1, hjust=1))+
  .leg_none






  