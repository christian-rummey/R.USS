
dt. <- readRDS('DATA derived/dt.all.visits.rds')

dt. %>% filter(!has.USS)

dt. %<>% 
  group_by(avisitn, paramcd) %>% 
  filter(avisitn == min(avisitn))

dt. %<>% 
  # filter(study == 'CRCSCA') %>% 
  filter(!is.na(subtype)) %>% 
  filter(!subtype %in% c('SCA10','SCA7', 'SCA8'))


# add dates ---------------------------------------------------------------

dt. %<>% 
  left_join(
    .dd('visit.dates.CRCSCA') %>% 
      
      select(study, sjid, adt, avisitn)
  )
# %>% 
  # arrange(rev(adt))
  # filter(adt > as.Date('2024-01-01'))


# SARA over duration ------------------------------------------------------

dt. %>%
  filter(paramcd %in% c('SARA')) %>%
  ggplot()+geom_point()+
  aes( x = dur )+
  aes( y = aval)+
  aes( color = subtype )+
  facet_wrap(~subtype)+
  geom_smooth(method = lm)

# SARA less 10 vs USS -----------------------------------------------------

dt. %>% 
  filter(!is.na(subtype)) %>% 
  filter(has.USS, has.SARA) %>% 
  filter(paramcd %in% c('SARA','FARS.E','fSARA')) %>% 
  spread(paramcd, aval) %>% 
  # filter(SARA < 10) %>% 
  ggplot()+geom_point()+
  aes( x = SARA )+
  aes( y = FARS.E)+
  aes( color = subtype )+
  facet_wrap(~subtype)+
  geom_smooth(method = lm)+
  # coord_cartesian(ylim = c(0, 20))+
  geom_vline(xintercept = 2.5)

dt. %>% 
  filter(!is.na(subtype)) %>% 
  # filter(SARA < 2.5) %>% 
  filter(has.USS, has.SARA) %>% 
  filter(paramcd %in% c('SARA','FARS.E')) %>% 
  # spread(paramcd, aval) %>% 
  ggplot()+geom_density(alpha = .5)+
  aes( x = aval )+
  aes( fill = subtype )+
  facet_wrap(~paramcd)

dt.cum <- dt. %>%
  group_by(sjid, paramcd) %>% filter(avisitn == min(avisitn)) %>% ungroup %>% 
  filter( paramcd %in% c('SARA','FARS.E','fSARA') ) %>% 
  mutate(subtype = ifelse(study == 'UNIFAI', 'FRDA',subtype)) %>% 
  group_by( study, subtype, paramcd ) %>% 
  # Count how many patients have each aval value
  count(aval, name = "n") %>%
  # Arrange by increasing aval
  arrange(aval) %>%
  # Calculate cumulative sum
  mutate(
    cum_n = cumsum(n),
    pct_cum = cum_n / sum(n) * 100
  )


# do this by duration groups!
dt.cum %>%
  left_join(
    .rt('../../Ataxia/DATA other/scales.txt') %>% 
      select(paramcd, maxscore)
  ) %>% 
  # mutate(aval = aval/maxscore) %>% 
  
  ggplot()+geom_line(size = 1)+
  aes(x = aval)+
  aes(color = subtype)+
  aes(y = pct_cum)+
  facet_wrap(~paramcd, ncol = 3, scales = 'free_x')+
  .theme()+
  .leg('lr')


# say something about duration --------------------------------------------

dt.cum <- dt. %>% 
  group_by(sjid, paramcd) %>% filter(avisitn == min(avisitn)) %>% ungroup %>% 
  filter(dur<20) %>% 
  filter( paramcd %in% c('SARA','FARS.E','fSARA') ) %>% 
  mutate(subtype = ifelse(study == 'UNIFAI', 'FRDA',subtype)) %>% 
  filter( has.both ) %>% 
  group_by( study, subtype, paramcd ) %>% 
  # Count how many patients have each aval value
  arrange(dur) %>%
  count(dur, name = "n") %>%
  # Arrange by increasing aval
  # Calculate cumulative sum
  mutate(
    cum_n = cumsum(n),
    pct_cum = cum_n / sum(n) * 100
  )

dt.cum %>% 
  ggplot()+geom_line(size = 1)+
  aes(x = dur)+
  aes(color = subtype)+
  aes(y = pct_cum)+
  facet_wrap(.~paramcd, ncol = 3, scales = 'free_x')+
  .theme()+
  .leg('lr')


dt. %>% 
  filter(has.both) %>% 
  group_by(sjid, paramcd) %>% filter(avisitn == min(avisitn)) %>% ungroup %>% 
  # filter(dur<20) %>% 
  filter( paramcd %in% c('SARA','FARS.E','fSARA') ) %>% 
  mutate(subtype = ifelse(study == 'UNIFAI', 'FRDA',subtype)) %>% 
  filter(paramcd == 'FARS.E') %>% 
  group_by(subtype) %>% 
  summarize(n = n(), mean(dur, na.rm=T))
