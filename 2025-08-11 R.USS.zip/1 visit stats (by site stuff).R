
# . -----------------------------------------------------------------------

rm(list = ls())

source('.project.settings.R')

dt. <- readRDS('DATA derived/uss.etc.rds')

# vd. <- bind_rows(
#   .dd('visit.dates.CRCSCA') %>% filter( adt >= '2024-03-01' ),
#   .ds.UNIFAI('vf') %>% filter(vfperf == 'Yes')
#   ) %>%
#   select( study, sjid, avisitn )

dt. %<>% 
  filter( study == 'CRCSCA' ) %>% 
  filter( paramcd %in% c('FARS.E', 'SARA') ) %>% 
  spread( paramcd, aval )


dt. %<>% 
  right_join(
    
    .dd('visit.dates.CRCSCA') %>% 
      filter( adt >= '2024-03-01' ) %>% 
      select( study, sjid, avisitn )
    
    ) 

dt. %>% 
  filter( is.na( SARA ) & is.na(FARS.E) ) %>% 
  nrow

dt. %<>% 
  filter( !(is.na( SARA ) & is.na(FARS.E)) ) %>% 
  .gs %>% 
  mutate(avisitx = avisitn - min(avisitn) )

dt. %<>% 
  # filter( is.na(SARA) | is.na(FARS.E) ) %>% 
  left_join(
    
    .dd('demo.sca') %>% 
      select( study, sjid, site, sca )
  )


# available data ----------------------------------------------------------

dt. %>% 
  .ug %>% 
  mutate  ( visits = n() ) %>% 
  filter  ( !is.na( FARS.E ) ) %>% 
  group_by( visits ) %>% 
  summarise( n = n()) %>% 
  mutate( pct.USS = 100*n/visits ) %>% 
  arrange( -visits )

dt. %>% 
  filter(avisitx == 0) %>% 
  filter(!is.na(FARS.E)) %>% 
  summary

# by site stuff ----------------------------------------------------------

p <- dt. %>% 
  ggplot()+geom_point()+
  aes(x = SARA, y = FARS.E )+
  facet_wrap(~site)

p + geom_rug(data = filter(dt., is.na(FARS.E)))

dt. %>% 
  group_by( site ) %>% 
  mutate  ( visits = n() ) %>% 
  filter  ( !is.na( FARS.E ) ) %>% 
  group_by( site, visits ) %>% 
  summarise( n = n()) %>% 
  mutate( pct.USS = 100*n/visits ) %>% 
  arrange( -visits )




