
# . -----------------------------------------------------------------------

rm(list = ls())

source('.project.settings.R')

dt. <- readRDS('DATA derived/dt.all.visits.rds')

params. <- c('ADL','SARA','FARS.E','fSARA','SARA.ax','SARA.ki','fane7')
labs.   <- c('ADL','SARA','USS','fSARA','SARA.ax','SARA.ki', 'E7')

dt. %<>% 
  mutate( paramcd = factor(paramcd, 
                           labels = labs.,
                           levels = params.,
  )) %>% 
  filter( !is.na(paramcd ) )

# %>% 
#   left_join(.dd('steps') %>% select(study, sjid, avisitn, amb))

# no flooring in corelations! ---------------------------------------------

# dt. %<>%
#   mutate(aval = floor(aval)) %>%
#   .gs %>% 
#   # filter(avisitx != 0 & (avisitn == min(avisitn)))
#   # filter(avisitn == min(avisitn)) %>%
#   .ug

# . -----------------------------------------------------------------------

dt. %>%
  select( study, sjid, avisitx, paramcd, aval) %>% 
  spread( paramcd, aval ) %>% 
  filter( !is.na(USS) ) %>% 
  unique() %>% 
  .ug %>% 
  select( study, avisitx ) %>% .tab

dt. %<>% 
  # left_join(
  #   
  #   .dd('demo.sca') %>% 
  #     select( study, sjid, site, sca )
  # ) %>% 
  # select( study, sjid, site, sca, avisitn, avisitx, paramcd, aval) %>% 
  .gsv %>% 
  # filter(n()==5) %>% 
  spread( paramcd, aval ) 

dt. %<>% 
  mutate( amb = ifelse(E7<5, 'amb', 'non-amb.')) %>% 
  filter( !is.na(SARA) & !is.na(USS) | study == 'UNIFAI')

dt.tmp <- dt. %>% 
  gather( paramcd, aval, ADL, SARA, fSARA, SARA.ax, SARA.ki )

dt.tmp %>% 
  .ug %>% 
  select(study, paramcd) %>% .tab

# SARA, fSARA //SARA.ax/app vs USS ---------------------------------------------

dt.tmp %>%
  filter(has.both) %>% 
  .gs %>% filter(avisitn == min(avisitn)) %>% ungroup %>% 
  filter(!is.na(aval)) %>% 
  filter(!is.na(E7)) %>% 
  # .gs %>% filter(avisitn == min(avisitn)) %>%
  # filter( paramcd %in% c('SARA','fSARA','SARA.ax','SARA.ki')) %>%
  filter( paramcd %in% c('ADL','SARA','fSARA')) %>%
  mutate( paramcd = factor(paramcd, c('ADL','SARA','fSARA'))) %>%
  # filter(!sca %in% c('SCA1','SCA10','SCA8','SCA7','RFC1')) %>%
  ggplot()+geom_point()+
  aes ( y = USS, x = aval )+
  # aes ( shape = amb )+.ssmA+
  aes ( color = amb )+ggsci::scale_color_d3()+
  # aes ( color = amb )+
  # aes ( color = amb )+
  # facet_wrap( paramcd~study, scales = 'free_x', ncol = 2 )+
  facet_wrap( ~paste(study, paramcd, sep=', '), scales = 'free_x', ncol = 3 )+
  ggpmisc::stat_correlation(
    # label.x = 0.04, 
    # label.y = 0.19
    aes(label = paste(after_stat(rr.label))),
        size =  10 / .pt,
        family = theme_get()$text$family
    )+
  # stat_regline_equation    (  )+
  # stat_regline_equation    ( label.x = 2 , label.y = 39 )+
  geom_smooth(method = lm, se =F)+
  coord_cartesian(ylim = c(0, 36))+
  labs(color = 'Ambulation (by E7)', y = "Upright Stability Score")+
  .leg('none')

# .sp( ti = 'USS vs ADL, SARA, f-SARA', l = "F", i = 1)

# ADL vs others -----------------------------------------------------------

dt.tmp %>%
  filter(has.both) %>% 
  spread(paramcd, aval) %>% 
  gather(paramcd, aval, USS, fSARA, SARA, SARA.ax, SARA.ki ) %>% 
  .gs %>% filter(avisitn == min(avisitn)) %>% ungroup %>% 
  filter(!is.na(aval)) %>% 
  filter(!is.na(E7)) %>% 
  # .gs %>% filter(avisitn == min(avisitn)) %>%
  # filter( paramcd %in% c('SARA','fSARA','SARA.ax','SARA.ki')) %>%
  filter( paramcd %in% c('USS','SARA','fSARA')) %>%
  mutate( paramcd = factor(paramcd, c('USS','SARA','fSARA'))) %>%
  # filter(!sca %in% c('SCA1','SCA10','SCA8','SCA7','RFC1')) %>%
  ggplot()+geom_point()+
  aes ( y = ADL, x = aval )+
  # aes ( shape = amb )+.ssmA+
  aes ( color = amb )+ggsci::scale_color_d3()+
  # aes ( color = amb )+
  # aes ( color = amb )+
  # facet_wrap( paramcd~study, scales = 'free_x', ncol = 2 )+
  facet_wrap( ~paste(study, paramcd, sep=', '), scales = 'free_x', ncol = 3 )+
  ggpmisc::stat_correlation(
    # label.x = 0.04, 
    # label.y = 0.19
    aes(label = paste(after_stat(rr.label))),
    size =  10 / .pt,
    family = theme_get()$text$family
  )+
  # stat_regline_equation    (  )+
  # stat_regline_equation    ( label.x = 2 , label.y = 39 )+
  geom_smooth(method = lm, se =F)+
  coord_cartesian(ylim = c(0, 36))+
  labs(color = 'Ambulation (by E7)', y = "Activities of Daily Living (ADL)")+
  .leg('none')

# .sp( ti = 'ADL vs USS, SARA, f-SARA', l = "F", i = 1)






# # USS by duration vs SARA -------------------------------------------------
# 
# dt.tmp <- dt. %>% 
#   filter(!is.na(USS)) %>% 
#   filter(!is.na(SARA)) %>% 
#   filter(!is.na(amb)) %>% 
#   filter(!is.na(dur)) %>% 
#   gather( paramcd, aval, USS, SARA, fSARA, SARA.ax, SARA.ki ) 
# 
# dt.tmp %>% 
#   .ug %>% 
#   select(study, paramcd) %>% .tab
# 
# # sjids <- dt.tmp %>% 
# #   .gs %>% 
# #   filter(paramcd == 'USS') %>% 
# #   filter( min(time.)>0 ) %>% select(sjid)
# # 
# # dt.tmp %>% 
# #   inner_join(sjids) %>% 
# #   spread(paramcd, aval)
# 
# dt.tmp %>% 
#   filter(amb == 'amb') %>% 
#   # filter(study == 'CRCSCA') %>% 
#   # filter(paramcd == 'USS') %>% 
#   .gs() %>% 
#   filter(!is.na(aval)) %>% 
#   filter(dur < 30) %>%
#   # filter( paramcd %in% c('SARA','fSARA')) %>%
#   # filter( !paramcd %in% c('SARA','fSARA')) %>% 
#   # filter(!sca %in% c('SCA1','SCA10','SCA8','SCA7','RFC1')) %>%
#   ggplot()+geom_point()+
#   geom_line(aes(group= sjid))+
#   aes ( x = dur, y = aval )+
#   aes ( color = amb )+ggsci::scale_color_d3()+
#   # aes ( color = amb )+
#   # aes ( color = amb )+
#   facet_grid( study~paramcd, scales = 'free_y' )+
#   ggpmisc::stat_correlation(
#     # label.x = 0.04,
#     # label.y = 0.19
#     aes(label = paste(after_stat(rr.label))),
#     size =  10 / .pt,
#     family = theme_get()$text$family,
#     # color = 'red'
#   )+
#   # stat_regline_equation    (  )+
#   # stat_regline_equation    ( label.x = 2 , label.y = 39 )+
#   geom_smooth(method = lm, se =F, color = 'red')+
#   # coord_cartesian(ylim = c(0, 36))+
#   labs(shape = 'Ambulation (by E7)')+
#   .theme(base_size = 14)
# 
# # .sp( ti = 'Correlation by Duration.age', l = '1s', i = 2 )
# 
# dt.tmp %>% spread(paramcd, aval) %>% filter(USS== 0) %>% .p
# 
# # SARA, fSARA, SARA.ax vs USS ---------------------------------------------
# 
