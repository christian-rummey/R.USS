



threshold_fane_items <- function(df, cols) {
  df %>%
    mutate(across(all_of(cols), ~ if_else(.x >= if_else(cur_column() == "fane7", 5, 4), 1, 0)))
}

# . -----------------------------------------------------------------------

steps.hier <- .dd('fars.w') %>% 
  filter(study %in% c('CRCSCA','UNIFAI')) %>%
  select(study, sjid, avisitn, .l.FARS.E, FARS.E) %>% 
  left_join(
    .dd('steps') %>% 
      select(study, sjid, avisitn, step.act, balance.step)
  ) %>% 
  select(-fane1, -fane6)

steps.hier

# Define your columns
fane_items <- c("fane5", "fane4", "fane3b", "fane2b", "fane3a", "fane2a", "fane7")

# Apply thresholding
steps.bin <- steps.hier %>%
  threshold_fane_items(fane_items)

valid_patterns <- map_chr(0:7, ~ paste0(strrep("0", .x), strrep("1", 7 - .x)))

# Column orders by disease
fane_items_fa  <- c("fane5", "fane4", "fane3b", "fane2b", "fane3a", "fane2a", "fane7")
fane_items_sca <- c("fane5", "fane4", "fane3b", "fane3a", "fane2b", "fane2a", "fane7")

# Build violation table
violations <- steps.bin %>%
  select( study, sjid, avisitn,         all_of(fane_items_fa  ) , everything()) %>% 
  mutate( pattern_fa = pmap_chr(across( all_of(fane_items_fa  ) ), paste0, collapse = "")) %>% 
  select( study, sjid, avisitn,         all_of(fane_items_sca ) , everything()) %>% 
  mutate( pattern_sca = pmap_chr(across( all_of(fane_items_sca ) ), paste0, collapse = "")) %>% 
  mutate( 
    pattern = case_when(
      study == "CRCSCA" ~ pattern_sca, 
      study == "UNIFAI" ~ pattern_fa
      )
    ) %>% 
  mutate(
    breaks_hierarchy = str_detect(pattern, "01")
  )

# violations %>% 
#   filter( study == 'CRCSCA' ) %>% 
#   filter( breaks_hierarchy )

violations %>%
  count(study, breaks_hierarchy) %>%
  group_by(study) %>%
  mutate(pct = n / sum(n))

has.both. <- dt.tmp %>% 
  filter(has.both) %>% 
  select(study, sjid, avisitn) %>% 
  unique

has.both. %>% group_by(study, sjid, avisitn)

violations %<>% 
  # inner_join(has.both.) %>% 
  # filter(!breaks_hierarchy) %>% 
  droplevels()

violations %>% 
  filter( !breaks_hierarchy ) %>%
  select( pattern ) %>% table

pattern_colors <- c(
  "0000000" = "#deebf7",  # light blue
  "1000000" = "#9ecae1",  # medium blue
  "1100000" = "#3182bd",  # dark blue
  
  "1110000" = "#c7e9c0",  # light mint green
  "1111000" = "#74c476",  # medium green
  "1111100" = "#238b45",  # dark green
  
  "1111110" = "#bdbdbd",  # light grey
  "1111111" = "#525252"   # dark grey
)



A <- violations %>%
  ggplot() +
  geom_density(alpha = 0.75, adjust = 1.5) +
  aes(y = after_stat(count))+
  aes(fill = pattern)+
  aes(x = FARS.E)+
  facet_wrap( ~ study, scales = "free", ncol = 2) +
  scale_fill_manual(values = pattern_colors, na.value = "transparent")+
  .theme(base_size = 14)+
  labs(fill = 'Balance Step')

B <- violations %>%
  ggplot() +
  geom_histogram(alpha = 0.75) +
  aes(y = after_stat(count))+
  aes(fill = pattern)+
  aes(x = FARS.E)+
  facet_wrap( ~ study, scales = "free", ncol = 2) +
  scale_fill_manual(values = pattern_colors, na.value = "transparent")+
  .theme(base_size = 14)+
  labs(fill = 'Balance Step')+
  .leg('none')


p <- ggarrange(A, B, ncol = 1)


.sp( )

