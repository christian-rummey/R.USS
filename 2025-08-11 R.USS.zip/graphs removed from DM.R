

dt. %>% 
  mutate(paramcd = factor(paramcd, c('fSARA','SARA.ax','SARA.gp','SARA','SARA.ap',.l.sara.ax))) %>% 
  filter(paramcd %in% c('SARA','SARA.ax','SARA.ap','SARA.gp') ) %>% 
  # filter(study == 'CRCSCA') %>%
  # filter(!sca %in% c('SCA1','SCA10','SCA8','SCA7','RFC1')) %>% 
  ggplot()+geom_point()+
  aes ( y = USS, x = aval )+
  # aes ( shape = study )+.ssmA+
  # aes ( color = study )+
  aes ( color = sca )+
  # facet_wrap( ~paramcd, scales = 'free_x' )+
  facet_grid( paramcd~study, scales = 'free_x' )+
  # .leg_tl+
  # geom_abline()+
  geom_smooth(method = lm, se =F)


dt. %>% 
  spread(paramcd, aval) %>% 
  filter(!is.na(fds)) %>% 
  filter(fds > 0) %>% 
  filter(fds <= 5) %>% 
  select(-.l.sara.ax, -'SARA.gp') %>% 
  gather ( paramcd, aval, 'USS', 'fSARA','SARA','SARA.ax','SARA.ap') %>% 
  mutate(paramcd = factor(paramcd, c('USS','fSARA','SARA','SARA.ax','SARA.gp','SARA.ap',.l.sara.ax))) %>% 
  filter(paramcd %in% c('USS','fSARA','SARA','SARA.ax','SARA.ap','SARA.gp') ) %>% 
  filter(paramcd %in% c('USS','fSARA','SARA','SARA.ax','SARA.ap','SARA.gp') ) %>% 
  # filter(study == 'CRCSCA') %>%
  filter(study %in% c('CRCSCA','FACOMS')) %>%
  # filter(!sca %in% c('SCA1','SCA10','SCA8','SCA7','RFC1')) %>% 
  ggplot()+geom_boxplot()+
  aes ( y = aval, x = factor(fds) )+
  # aes ( shape = study )+.ssmA+
  # aes ( color = study )+
  aes ( fill = study )+
  facet_wrap( ~paramcd, scales = 'free_y' )+
  # facet_grid( ~paramcd, scales = 'free_x' )+
  # .leg_lr+
  # geom_abline()+
  geom_smooth(method = lm, se =F)



dt. %>% 
  filter(sca == 'SCA27B') %>% 
  spread(paramcd, aval) %>%
  left_join(.dd('demo.sca') %>% select(sjid, age_bl)) %>% 
  select(study, age = age_bl, USS, SARA, fSARA )

filter(!is.na(fds)) %>% 
  filter(fds > 0) %>% 
  filter(fds <= 5) %>% 
  select(-.l.sara.ax, -'SARA.gp') %>% 
  gather ( paramcd, aval, 'USS', 'fSARA','SARA','SARA.ax','SARA.ap') %>% 
  mutate(paramcd = factor(paramcd, c('USS','fSARA','SARA','SARA.ax','SARA.gp','SARA.ap',.l.sara.ax))) %>% 
  filter(paramcd %in% c('USS','fSARA','SARA','SARA.ax','SARA.ap','SARA.gp') ) %>% 
  filter(paramcd %in% c('USS','fSARA','SARA','SARA.ax','SARA.ap','SARA.gp') ) %>% 
  # filter(study == 'CRCSCA') %>%
  filter(study %in% c('CRCSCA','FACOMS')) %>%
  # filter(!sca %in% c('SCA1','SCA10','SCA8','SCA7','RFC1')) %>% 
  ggplot()+geom_boxplot()+
  aes ( y = aval, x = factor(fds) )+
  # aes ( shape = study )+.ssmA+
  # aes ( color = study )+
  aes ( fill = study )+
  facet_wrap( ~paramcd, scales = 'free_y' )+
  # facet_grid( ~paramcd, scales = 'free_x' )+
  .leg_lr+
  # geom_abline()+
  geom_smooth(method = lm, se =F)
