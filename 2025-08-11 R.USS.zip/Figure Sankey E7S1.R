


dt.tmp <- bind_rows(
  .dd('sara'),
  .dd('fars')
  ) %>%
  filter( paramcd %in% c('s1.gait', 'fane7')) %>% 
  filter( !is.na(aval) ) %>% 
  select(-avisit, -age, -time.) %>% 
  spread( paramcd, aval ) %>% 
  # filter(study == 'TRACKFA') %>%
  # pull(study) %>% table
  # filter( sjid == 'CU006') %>% 
  filter( !is.na( fane7 ) & !is.na(s1.gait)  )
  

.dd('visit.dates.CRCSCA')  
.dd('visit.dates.UNIFAI')  

dm. <- bind_rows(
  .dd('demo') %>% select(study, sjid, dob),
  .dd('demo.sca') %>% select(study, sjid, sca)
)


# correlation E7/S1 -------------------------------------------------------

dt.tmp %>% 
  left_join(dm.) %>% filter(!is.na(sca)) %>%
  # pull(study) %>% table
  ggplot()+geom_jitter(height = .01, width = 0.01)+
  aes(y = fane7, x = s1.gait)+
  # geom_smooth( formula = y ~ poly(x, 2), method = 'lm', color = 'blue')
  geom_smooth( method = lm, color = 'red')+
  # stat_regline_equation()+
  stat_cor               (aes(label = paste(..rr.label..)), r.digits = 2)+
  ggpmisc::stat_correlation(aes(label = paste(..r.label..)))+
  facet_wrap( ~study, ncol = 1)
  # geom_abline(slope = y.max/x.max, linetype = 'dotted') +)
  
  
dt.tmp %>% 
  group_by(sjid) %>% filter(adt == min(adt)) %>% 
  # filter(study != 'CRCSCA') %>% 
  mutate( fane7 = fane7/5, s1.gait = s1.gait/8 ) %>%
  # filter( fane7 != 1 & s1.gait != 1) %>% 
  mutate( pct.diff = abs(fane7 - s1.gait )) %>% 
  # mutate( study = 'all') %>% 
  ungroup %>% 
  mutate( N = n()) %>% 
  group_by( study, N) %>% 
  filter( pct.diff > .2 ) %>% 
  mutate( n = n()) %>% 
  reframe(pct = n/N)
  # left_join(dm.) %>% filter(!is.na(sca)) %>%
  # pull(study) %>% table
  ggplot()+
  # geom_jitter(height = .01, width = 0.01)+
  # aes(y = pct.diff, x = fane7 )+
  geom_histogram()+aes(x = pct.diff)+
  # geom_smooth( formula = y ~ poly(x, 2), method = 'lm', color = 'blue')
  geom_smooth( method = lm, color = 'red')
  


dt.flow <- dt.tmp %>% 
  # mutate( fane7 = fane7/5, s1.gait = s1.gait/8 ) %>%
  # group_by(sjid) %>% filter(adt == min(adt)) %>% 
  # filter(study != 'CRCSCA') %>% 
  mutate( fane7 = fane7/5, s1.gait = s1.gait/8 ) %>%
  gather(paramcd, aval, s1.gait, fane7) %>% 
  ggplot()+geom_jitter(width = 0.1)+
  geom_line(aes(group = sjid))+
  aes(x = paramcd, y = aval)


library(ggalluvial)

dt.tmp %>%
  group_by(study) %>% 
  # filter(study != 'CRCSCA') %>% 
  # mutate( fane7 = fane7/5, s1.gait = s1.gait/8 ) %>%
  gather(paramcd, aval, s1.gait, fane7)

dt.flow <- dt.tmp %>%
  # mutate( fane7 = fane7/5, s1.gait = s1.gait/8 ) %>%
  group_by(sjid) %>% 
  filter(adt == min(adt)) %>% 
  distinct(study, sjid, fane7, s1.gait) %>%  # ensure unique subjects
  select(study, sjid, fane7, s1.gait) %>%  # ensure unique subjects
  group_by(study) %>% 
  count(fane7, s1.gait, name = "n")   # count transitions


ggplot(dt.flow,
       aes(axis1 = fane7, axis2 = s1.gait, y = n)) +
  geom_alluvium(aes(fill = factor(fane7)), width = 1/12) +
  geom_stratum(width = 1/12, fill = "grey90", color = "black") +
  geom_text(stat = "stratum", aes(label = after_stat(stratum))) +
  scale_x_discrete(limits = c("E7", "s1.gait"), expand = c(.05, .05)) +
  # labs(title = "Transition from E7 to Gait Score", y = "Number of Subjects") +
  theme_minimal()+
  facet_wrap(~study, scales = 'free_y')


